﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Celulares73A.Model;
using Celulares73A.Model.Entidades;

namespace Celulares73A.Desktop
{
    public partial class frmNovo : Form
    {
        private List<Fabricante> fab;
        public frmNovo()
        {
            InitializeComponent();
        }
        internal class Show : frmNovo
        {
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if(txtModelo.Text != "")
            {
                Aparelho ap = new Aparelho();
                ap.Modelo = txtModelo.Text;
                ap.Largura = numLargura.Value;
                ap.Altura = numAltura.Value;
                ap.Espessura = numEspessura.Value;
                ap.Peso = numPeso.Value;
                ap.Quantidade = Convert.ToInt32(numQuantidade.Value);
                ap.Preco = numPreco.Value;
                ap.Desconto = numDesconto.Value;
                ap.Fabricante = fab[cmbFabricante.SelectedIndex];

                Servico.Salvar(ap);
                MessageBox.Show("O aparelho foi salvo com sucesso!",
                                "Celular CTI 2022",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Exclamation);
                this.Close();
            }
            else
            {
                MessageBox.Show("Error!",
                               "Celular CTI 2022",
                               MessageBoxButtons.OK,
                               MessageBoxIcon.Error);
                this.Close();
            }                       
        }

        private void frmNovo_Load(object sender, EventArgs e)
        {
            fab = Servico.todosFabricantes();
            foreach (Fabricante fab in fab)
                cmbFabricante.Items.Add(fab.Nome);
        }              
    }
}
