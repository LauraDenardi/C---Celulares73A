﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Celulares73A.Model.Entidades;
using Celulares73A.Model;

namespace Celulares73A.Desktop
{
    public partial class frmPrincipal : Form
    {
        List<Aparelho> aparelhos = new List<Aparelho>();
        List<Fabricante> fabricantes = new List<Fabricante>();

        public frmPrincipal()
        {
            InitializeComponent();
        }

        //--------------------*
        private void preencherLista()
        {
            lstCelulares.Items.Clear();
            foreach (Aparelho ap in aparelhos)
                lstCelulares.Items.Add(ap);
        }
        //------------------------------------*

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            aparelhos = Servico.PesquisarAparelho();
            lstCelulares.DataSource = aparelhos;

            fabricantes = Servico.todosFabricantes();
            cmbFabricante.DataSource = fabricantes;
            cmbFabricante.ValueMember = "id_fabricante";
            cmbFabricante.DisplayMember = "nome";
            cmbFabricante.SelectedIndex = -1;
        }

        private void btnBuscarFabricante_Click(object sender, EventArgs e)
        {
            aparelhos = Servico.PesquisarAparelho(fabricantes[cmbFabricante.SelectedIndex]);
            lstCelulares.DataSource = aparelhos;
        }

        private void btnBuscarModelo_Click(object sender, EventArgs e)
        {
            aparelhos = Servico.PesquisarAparelho(txtModelo.Text);
            lstCelulares.DataSource = aparelhos;


        }

        private void btnBuscaPreco_Click(object sender, EventArgs e)
        {
            if(numPrecoMin.Value < numPrecoMax.Value)
            {
                MessageBox.Show("O preço maximo deve ser maior ou igual ao preço minimo",
                                "Celular CTI 2022",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Exclamation);
                numPrecoMax.Focus();
                return;
            }
            aparelhos = Servico.PesquisarAparelho(numPrecoMin.Value, numPrecoMax.Value);

            lstCelulares.DataSource = aparelhos;

        }

        private void btnComprar_Click(object sender, EventArgs e)
        {
            if(lstCelulares.SelectedIndex != -1)
            {
                frmComprar compra = new frmComprar(aparelhos[lstCelulares.SelectedIndex]);
                compra.ShowDialog();
            }

            else
            {
                MessageBox.Show("Você deve selecionar um aparelho!",
                                "Celular CTI 2022",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Exclamation);
                lstCelulares.Focus();
                //return;
            }
        }

        private void frmPrincipal_Activated(object sender, EventArgs e)
        {
            aparelhos = Servico.PesquisarAparelho();
            lstCelulares.DataSource = aparelhos;
        }

        //--------------------*
        private void btnNovo_Click(object sender, EventArgs e)
        {
            new frmNovo().Show();
        }

        //--------------------------*
    }
}
